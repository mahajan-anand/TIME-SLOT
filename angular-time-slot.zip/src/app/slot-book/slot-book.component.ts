import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slot-book',
  templateUrl: './slot-book.component.html',
  styleUrls: ['./slot-book.component.scss']
})
export class SlotBookComponent implements OnInit {

  constructor() { }
  bsInlineValue = new Date();
  bsInlineRangeValue: Date[];
  maxDate = new Date();
  ngOnInit(): void {
  }
  data: any;
  onValueChange(value: Date): void {
    this.data = value;
  }
}
