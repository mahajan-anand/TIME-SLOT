import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SlotAvailableComponent } from './slot-available.component';

describe('SlotAvailableComponent', () => {
  let component: SlotAvailableComponent;
  let fixture: ComponentFixture<SlotAvailableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SlotAvailableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SlotAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
