import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { from } from 'rxjs';

@Component({
  selector: 'app-slot-available',
  templateUrl: './slot-available.component.html',
  styleUrls: ['./slot-available.component.scss']
})
export class SlotAvailableComponent implements OnInit {

  constructor(private formBuilder: FormBuilder) {
    
  }
  timeSlotForm: FormGroup;
  ngOnInit(): void {
    this.initializeForm();
  }
  
  weekDayTimeSlot: any = {
    Monday: { id: 'M', data: [] },
    Tuesday: { id: 'T', data: [] },
    Wednesday: { id: 'W', data: [] },
    Thursday: { id: 'T', data: [] },
    Friday: { id: 'F', data: [] },
    Saturday: { id: 'S', data: [] },
    Sunday: { id: 'S', data: [] }
  }

  initializeForm() {
    if (localStorage.getItem('availableTimeSlot')) {
      this.weekDayTimeSlot = JSON.parse(localStorage.getItem('availableTimeSlot'));
    }
    this.timeSlotForm = this.formBuilder.group({ weekArray: this.formBuilder.array([]) });
    const weekArray = this.timeSlotForm.controls['weekArray'] as FormArray;

    Object.keys(this.weekDayTimeSlot).forEach(element => {
      let formGroup: FormGroup = this.formBuilder.group({});
      formGroup.addControl('weekDayName', new FormControl(element));
      formGroup.addControl('nameInitial', new FormControl(this.weekDayTimeSlot[element].id));
      let dataArray = this.formBuilder.array([]) as FormArray;
      if (this.weekDayTimeSlot[element].data.length > 0) {
        this.weekDayTimeSlot[element].data.forEach(e => {
          let currentFromDate = new Date();
          let currentToDate = new Date();
          currentFromDate.setHours(e.fromTime.split(':')[0]);
          currentFromDate.setMinutes(e.fromTime.split(':')[1]);
          currentToDate.setHours(e.toTime.split(':')[0]);
          currentToDate.setMinutes(e.toTime.split(':')[1]);
          dataArray.push(this.createItem(currentFromDate, currentToDate));
        });
        formGroup.addControl('data', dataArray);
      }
      else {
        formGroup.addControl('data', this.formBuilder.array([this.createItem()]))
      }
      weekArray.push(formGroup);
    });
  }

  createItem(fromTime = null, toTime = null): FormGroup {
    return this.formBuilder.group({
      fromTime: fromTime,
      toTime: toTime,
    });
  }

  addTimeControl(index) {
    const formArray = this.timeSlotForm.controls['weekArray'] as FormArray;
    ((formArray.at(index) as FormGroup).controls['data'] as FormArray).push(this.createItem());
  }
  removeTimeControl(index, childIndex) {
    const formArray = this.timeSlotForm.controls['weekArray'] as FormArray;
    ((formArray.at(index) as FormGroup).controls['data'] as FormArray).removeAt(childIndex);
  }

  saveTimeSlot() {
    for (let weekControl of this.timeSlotForm.get('weekArray')['controls']) {
      let weekDayName = weekControl.controls["weekDayName"].value;
      if (this.weekDayTimeSlot[weekDayName]) { this.weekDayTimeSlot[weekDayName].data = []; }
      if (weekControl.controls['data'] && weekControl.controls['data'].length > 0) {
        for (const timeControl of weekControl.controls['data']['controls']) {
          let fromTime = timeControl.controls["fromTime"].value;
          let toTime = timeControl.controls["toTime"].value;
          if (fromTime && toTime) {
            let obj = {
              fromTime: fromTime.getHours() + ':' + fromTime.getMinutes(), toTime: toTime.getHours() + ':' + toTime.getMinutes()
            }
            this.weekDayTimeSlot[weekDayName].data.push(obj);
          }
        }
      }
    }
    localStorage.setItem('availableTimeSlot', JSON.stringify(this.weekDayTimeSlot));
  }

  addWeekDay(key, index) {
    const formArray = this.timeSlotForm.controls['weekArray'] as FormArray;
    if (this.weekDayTimeSlot[key] && ((formArray.at(index) as FormGroup).controls['data'] as FormArray).length == 0) {
      let formGroup: FormGroup = this.formBuilder.group({});
      const weekArray = this.timeSlotForm.controls['weekArray'] as FormArray;
      formGroup.addControl('weekDayName', new FormControl(key));
      formGroup.addControl('nameInitial', new FormControl(this.weekDayTimeSlot[key].id));
      formGroup.addControl('data', this.formBuilder.array([this.createItem()]));
      weekArray.push(formGroup);
    }
  }
  returnZero() { return 0 }
}
